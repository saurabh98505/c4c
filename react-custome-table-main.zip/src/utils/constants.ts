export const COLOR_CODES = {
    white: '#ffffff',
    black: '#000000',
    lightGrey: '#e4e6ef',
    tabColor: '#098232',
    tabBtnColor: '#24c058',
    darkGrey: '#808080',
    tableBgColor: '#f5fef8',
};
